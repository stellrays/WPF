﻿using System.Windows;
using System.Data;
using System.Configuration;
using Microsoft.Data.SqlClient;
namespace WPFAppADONet
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            string connectionString = ConfigurationManager.ConnectionStrings["ConnectionLocalDb"].ConnectionString; ;
            string sql = "SELECT * FROM users";
            DataTable usersTable = new DataTable();
            SqlConnection connection = null;
            connection = new SqlConnection(connectionString);
            SqlCommand command = new SqlCommand(sql, connection);
            SqlDataAdapter adapter = new SqlDataAdapter(command);                      
            connection.Open();
            adapter.Fill(usersTable);
            UsersGrid.ItemsSource = usersTable.DefaultView;
        }
    }
}
